datos<-data10

normalidad(datos)

variables<-c()

jarque_pvalor<-c()
jarque_estadistico<-c()
jarque_distribucion<-c()

for (i in 10:42){
  variables[i-9]<-names(data[i])
  var<-as.numeric(na.exclude(as.vector(unlist(data[,i]))))
  aux1<-jarque.test(var)
  
  jarque_pvalor[i-9]<-aux1$p.value
  jarque_estadistico[i-9]<-aux1$statistic
  
  if (aux1$p.value<=0.05)
  {jarque_distribucion[i-9]<-"otra d."}
  
  else
  {jarque_distribucion[i-9]<-"d.normal"}
}
  
  
  normalidad_2<-data.frame(variables,jarque_estadistico,jarque_pvalor,jarque_distribucion)
  normalidad_2
  
  write.csv(normalidad_2, file ="normalidad.csv", row.names = F)




for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(na.exclude(as.vector(unlist(datos[,i]))))
  aux2<-ad.test(var)
  
  if (aux2$p.value<=0.05)
  {anderson_distribucion[i-9]<-"otra d."}
  
  else
  {anderson_distribucion[i-9]<-"d.normal"}
  
  
  normalidad_2<-data.frame(variables,anderson_estadistico,anderson_pvalor,
                           anderson_distribucion)
  normalidad_2
  
  write.csv(normalidad_2, file ="normalidad2.csv", row.names = F)}

#asi si sale
x<-na.exclude(data$a2)
a<-as.vector(x)
b<-as.numeric(a)
jarque.test(b)

#asi no sale
d<-as.vector(datos$gran_total)
e<-na.exclude(d)
jarque.test(d)

#####
jarque.test(data$gran_total)
jarque.test(data$a2)


ad.test(datos$gran_total)

#Para crear vectores excluyendo na's
data$gran_total
b<-na.exclude(data$gran_total)
c<-as.vector(na.exclude(data$gran_total))


#probamos bartlett.test

bartlett.test(data$gran_total~data$Genero)


#probamos wilcox.test

wilcox.test(data$gran_total~data$Nivel,conf.int=T)


#probamos levenne.test

prueba_levene <-leveneTest(data$a1,data$Sexo)

prueba_levene$`Pr(>F)`

levels(data$Edad)

edad <- as.factor(data$Edad)

levels(edad)

#probamos kruskal.test

kruskal.test(datos$gran_total,grupo2)

#probamos dunn.test

library(dunn.test)

q<-dunn.test(data$gran_total,data$Grado,method="bonferroni", list=T)

q$Z
q$P
q$altP
q$P.adjusted
q$altP.adjust
q$comparisons

q<-dunn.test(data$gran_total,data$Grado,method="bonferroni", list=T)

prueba<-dunn.test(data12$gran_total,data$Grado,method="bonferroni", list=T)

prueba$comparisons
prueba$comparisons$2
prueba$comparisons[2]
