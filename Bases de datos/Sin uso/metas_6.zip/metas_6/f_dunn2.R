
prueba_dunn <- function(datos,grupos){
  
  if(!require(dunn.test)) install.packages('dunn.test')
  require(dunn.test)

  for (i in 1:11){
  var<-as.numeric(as.vector(unlist(datos[,i])))
  dunn.test(var,grupos,method="bonferroni", list=T)}
}

