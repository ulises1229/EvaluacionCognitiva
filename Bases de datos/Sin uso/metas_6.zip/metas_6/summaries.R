summary(data$Edad)
sd(data$Edad)
