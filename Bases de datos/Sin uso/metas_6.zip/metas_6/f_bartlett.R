
prueba_bartlett<-function(datos,grupos){

variables<-c()

bartlett_estadistico<-c()
bartlett_gradoslibertad<-c()
bartlett_pvalor<-c()
bartlett_varianzas<-c()

for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(unlist(datos[,i]))
  aux1<-bartlett.test(var~grupos)
  bartlett_estadistico[i-9]<-aux1$statistic
  bartlett_gradoslibertad[i-9]<-aux1$parameter
  bartlett_pvalor[i-9]<-aux1$p.value
  
  
  if (aux1$p.value<=0.05)
  {bartlett_varianzas[i-9]<-"diferentes"}
  
  else
  {bartlett_varianzas[i-9]<-"iguales"}
  
}

varianzas<-data.frame(variables,bartlett_estadistico,bartlett_gradoslibertad,
                           bartlett_pvalor,bartlett_varianzas)

write.csv(varianzas, file ="varianzas.csv", row.names = F)

}
