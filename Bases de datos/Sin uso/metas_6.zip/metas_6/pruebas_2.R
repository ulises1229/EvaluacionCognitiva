ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,220)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_compare_means(method = "dunn.test", label.y =3.5) +
  stat_compare_means(label = "p.signif", ref.group = ".all.", size = 5, hide.ns = TRUE,
                     comparisons = list(c("Americas Unidas","Carol Baur"), c("Calli Montessori","Carol Baur"), 
                                        c("Carol Baur","Colegio Nuevo Milenio"),c("Americas Unidas","ISQ"), 
                                        c("Colegio Nuevo Milenio","ISQ"),c("Americas Unidas","Republica Francesa"),
                                        c("Carol Baur","Republica Francesa"), c("ISQ","Republica Francesa"),
                                        c("Americas Unidas","Saint Agustine School"), c("Calli Montessori","Saint Agustine School"),
                                        c("Colegio Nuevo Milenio","Saint Agustine School"),c("Republica Francesa","Saint Agustine School"),
                                        c("Americas Unidas","Secundaria Tecnica 14"),c("Carol Baur","Secundaria Tecnica 14"),
                                        c("ISQ","Secundaria Tecnica 14"),c("Saint Agustine School","Secundaria Tecnica 14")))

ggsave("E:/metas_6/diferencias/grupos/graficas_dif_grupos/diferencias_escuela_grantotal_2.jpeg")

ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,100)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_compare_means(method = "dunn.test", label.y =3.5) +
  stat_compare_means(label = "p.signif", ref.group = "Americas Unidas", size = 5, hide.ns = TRUE)



pvalues <-tibble (group1=as.factor(c("Americas Unidas","Calli Montessori","Carol Baur")), group2=as.factor(c("Carol Baur","Carol Baur","Colegio Nuevo Milenio")),
        p = c(0.0000,0.0000,0.0000), y.position=c(70,80,90))


pvalues2 <-tibble (group1=1:3, group2=4:6,p = c(0.0000,0.0000,0.0000), y.position=c(70,80,90))


#No funciona
ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,110)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_pvalue_manual(pvalues2, label = "p", y.position = "y.position",
                   xmin = "group1", xmax = "group2", x = NULL, size = 3.88,
                   label.size = size, bracket.size = 0.3, tip.length = 0.03,
                   remove.bracket = FALSE)

datos2<-read.csv("Libro2.csv")


ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,110)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_compare_means(method = "dunn.test", label.y =80) +
  stat_compare_means(label = "p.signif", ref.group = ".all.", size = 5, hide.ns = T, comparisons = list(c("Americas Unidas","Carol Baur")) +
  stat_compare_means(label = "p.signif", ref.group = ".all.", size = 5, hide.ns = T, comparisons = list(c("Americas Unidas","ISQ"))
             
                     #c("Americas Unidas","ISQ"), 
                     #c("Americas Unidas","Republica Francesa"),c("Americas Unidas","Saint Agustine School"),
                     #c("Americas Unidas","Secundaria Tecnica 14")))

                     
#sobrantes          
my_comparisons<-list(c("Americas Unidas","Carol Baur"), c("Calli Montessori","Carol Baur"), c("Carol Baur","Colegio Nuevo Milenio"))
                     
my_comparisons<-list(c("Americas Unidas","Republica Francesa"))

ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,110)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_compare_means(method = "kruskal.test",label.y.npc=0.03,label = "p.signif", ref.group = ".all.", size = 4, hide.ns = TRUE,
                     comparisons = list(c("Americas Unidas", "Colegio Nuevo Milenio")),tip.length=0.02,bracket.size= 0.0001)




c("Colegio Nuevo Milenio","ISQ")
c("Americas Unidas","ISQ")

label.y.npc="centre"

label.y =c(71,81,91)

+
  stat_compare_means(label = "p.signif", ref.group = ".all.", size = 5, hide.ns = TRUE,
                     comparisons = list(c("Calli Montessori","Carol Baur")))+
  stat_compare_means(label = "p.signif", ref.group = ".all.", size = 5, hide.ns = TRUE,
                     comparisons = list(c("Carol Baur","Colegio Nuevo Milenio")))

#method = "dunn.test", label.y =100, 

#stat_compare_means(method = "dunn.test", label.y =90)+

#stat_compare_means(method = "dunn.test", label.y =100)+                                    


#comparisons = list(c("Americas Unidas", "Carol Baur")))
#+
#stat_pvalue_manual(pvalues1, label = "p", y.position = "y.position",
#xmin = "grupo1", xmax = "grupo2", x = NULL, size = 3.88,
#label.size = size, bracket.size = 0.3, tip.length = 0.03,
#remove.bracket = FALSE)





stat.test <- df %>% dunn.test(data$a1,data$Escuela,method="bonferroni", list=T)

#Con esto se les pone un rombo negro (ombligo) a las graficas que indica el valor de la media de ese grupo
stat_summary(fun.y = mean, geom = "point", shape = 23, size = 3, fill = 'black')+
  guides(fill = FALSE)

#Con esto se añade el valor de la mediana (o de la media, segun uno decida y sus rangos, esto se decide con fun)
#de forma grafia (rombo y lineas o lo que uno quiera)

add_summary(grafica1, fun = "median", error.plot = "pointrange",
            color = "black", fill = "white", group = 1, width = NULL,
            shape = 19, size = 1, ci = 0.95, data = NULL,
            position = position_dodge(0.8))


add_summary(grafica1,"median_iqr")



#Investigar stat_pvalue_manual {ggpubr}

pvalues<-read.csv("pvalues.csv")
pvalues1<-as.data.frame(pvalues)
View(pvalues1)

stat_pvalue_manual(pvalues, label = "p", y.position = "y.position",
                   xmin = "group1", xmax = "group2", x = NULL, size = 3.88,
                   label.size = size, bracket.size = 0.3, tip.length = 0.03,
                   remove.bracket = FALSE, ...)




#ggsave("E:/metas_6/diferencias/grupos/graficas_dif_grupos/diferencias_escuela_grantotal.jpeg")
ggsave("/media/navarreten/KINGSTON/metas_6/diferencias/grupos/graficas_dif_grupos/diferencias_escuela_grantotal.jpeg")



ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,110)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_compare_means(method = "dunn.test", label.y =80,label = "p.signif", ref.group = ".all.", size = 4, hide.ns = F, comparisons = list(c("Americas Unidas","Carol Baur")))+
  stat_compare_means(method = "dunn.test", label.y =80,label = "p.signif", ref.group = ".all.", size = 4, hide.ns = T, comparisons = list(c("Americas Unidas","ISQ")))+
  stat_compare_means(method = "dunn.test", label.y =80,label = "p.signif", ref.group = ".all.", size = 4, hide.ns = T, comparisons = list(c("Americas Unidas","Republica Francesa")))+
  stat_compare_means(method = "dunn.test", label.y =100,label = "p.signif", ref.group = ".all.", size = 4, hide.ns = T, comparisons = list(c("Carol Baur","Colegio Nuevo Milenio")))

#c("Carol Baur","Colegio Nuevo Milenio")

#c("Americas Unidas","Saint Agustine School"),
#c("Americas Unidas","Secundaria Tecnica 14")))
                     
      
                                        