
datos<-data
grupos<-datos$Nivel

#1. Calcular normalidad de los datos

getwd()
setwd("E:/metas_6/normalidad/tablas_normalidad/")
getwd()

#install.packages("moments")
library("moments")#Para jarque.test
#install.packages("nortest")
library("nortest")#Para ad.test y otros de normalidad

source("E:/metas_6/f_normalidad.R")

#datos<-data10

normalidad(datos)

#2. Hacer graficas para evaluar normalidad de cada variable

getwd()
setwd("E:/metas_6/normalidad/graficas_normalidad_3_hm_ps_var/")
getwd()

source("E:/metas_6/f_grafnorm.R")

grafnorm(datos)

#3. Hacer multihistogramas para evaluar normalidad de cada variable de forma grafica
#Utilizamos psych= Paquete que permite hacer varios histogramas de una vez

getwd()
setwd("E:/metas_6/normalidad/multihist_3_hm_ps_var/")
getwd()

#install.packages("psych")
library(psych)

#Con USr le decimos que la orientacion del pdf es acostada y con weight
#y height indica el area del papel que ocupara la grafica

pdf("multihist1_hm_ps.pdf", width = 15, height = 15, paper = "USr")
multi.hist(data[ ,10:17])
dev.off()

pdf("multihist2_hm_ps.pdf", width = 15, height = 15, paper = "USr")
multi.hist(data[ ,18:30])
dev.off()

pdf("multihist3_hm_ps.pdf", width = 15, height = 15, paper = "USr")
multi.hist(data[ ,31:41])
dev.off()

pdf("multihist4_hm_ps.pdf", width = 15, height = 15, paper = "USr")
multi.hist(data[ ,42])
dev.off()

#Histogramas de todos los totales: parciales y generales
pdf("multihist5_hm_ps.pdf", width = 15, height = 15, paper = "USr")
multi.hist(data11)
dev.off()

#Histogramas de los totales generales de cada ejercicio
pdf("multihist6_hm_ps.pdf", width = 15, height = 15, paper = "USr")
multi.hist(data12)
dev.off()

#4. Calcular homogeneidad de varianzas con bartlett.test (aplicable a poblaciones no normales,
#mejor que var.test que es preferible para poblaciones normales)

getwd()
#setwd("E:/metas_6/varianza/tablas_varianza/varianzas_bartlett")
setwd("varianza/tablas_varianza/varianzas_bartlett")
getwd()

#source("E:/metas_6/f_bartlett.R")
source("/media/navarreten/KINGSTON/metas_6/f_bartlett.R")

prueba_bartlett(datos,grupos)

#5. leveneTest, parece que es mejor que bartlett porque es ideal para
#cuando las distribuciones no son normales y el estadistico de centralidad que
#utiliza por defecto es la mediana y no la media, aunque se puede elegir el estadistico
#de centralidad que se prefiera.

getwd()
#setwd("E:/metas_6/graficas_normalidad/tablas_varianza/varianzas_levene")
#setwd("varianza/tablas_varianza/varianzas_levene")
setwd("varianzas_levene")
getwd()

install.packages("car")
library("car")#Para leveneTest

source("E:/metas_6/f_levene.R")
source("/media/navarreten/KINGSTON/metas_6/f_levene.R")

prueba_levene(datos,grupos)

#Levene test se logra, pero arroja muchos warnings, asi que probablemente algo este mal. 
#Por el momento lo vamos a dejar asi, pero hay que checar. Es probable que no me
#este comparando entre todos los grupos, sino solo entre los 2 primeros, asi que hay que
#checar esto


#6. Evaluar diferencias entre grupos de sexo con prueba u de mann whitney que se hace con 
#wilcox.test(aplicable a poblaciones no normales)

getwd()
setwd("E:/metas_6/diferencias/sexo/")
#setwd("/media/navarreten/KINGSTON/metas_6/diferencias/sexo/")
getwd()

datos<-data
grupos<-datos$Sexo

source("E:/metas_6/f_wilcox.R")
#source("/media/navarreten/KINGSTON/metas_5/f_wilcox.R")

prueba_wilcox(datos,grupos)

#7. Evaluar diferencias entre grupos de nivel escolar(primaria y secundaria)
#con esta misma prueba u de mann whitney por ser solo 2 grupos

getwd()
setwd("E:/metas_6/diferencias/nivel/")
#setwd("/media/navarreten/KINGSTON/metas_6/diferencias/nivel/")
getwd()

grupos<-datos$Nivel
prueba_wilcox(datos,grupos)

#En proximas ocasiones es IMPORTANTE checar si es importante incluir los parametros
#de intervalo de confianza y diferencia en el output de esta prueba, eso se hace
#con el argumente conf.int = TRUE de wilcox.test y evaluar tambien si es IMPORTANTE que
#se ajusten los empates (checar minitab). Y checar que tambien que se hace con las NA's
#Tengo duda de que no este excluyendo NA's o algo asi (parce que si, pero hay que checar con 
#mas cuidado)


#8. Evaluar diferencias entre grupos(por grado escolar, edad y escuela) con prueba kruskall.wallis

datos<-data
grupo1<-as.factor(datos$Edad)
grupo2<-as.factor(datos$Grado)
grupo3<-datos$Escuela

getwd()
setwd("E:/metas_6/diferencias/grupos/")
getwd()

source("E:/metas_6/f_kruskal.R")

prueba_kruskal(datos,grupo1,grupo2,grupo3)

#9. Checar entre que grupos hay diferencias significativas de las variables en donde se identifico que hay diferencias significativas 
#con kruskal.wallis

getwd()
#setwd("E:/metas_6/diferencias/grupos/")
#setwd("/media/navarreten/KINGSTON/metas_6/diferencias/grupos/")
getwd()

datos<-data11
grupos<-data$Edad

source("E:/metas_6/f_dunn2.R")
source("/media/navarreten/KINGSTON/metas_6/f_dunn2.R")

prueba_dunn_1(datos,grupos)


prueba_dunn(datos,grupos)

#Va a ser necesario volver a correr kruskalwalis para ver edad, porque hubo problemas con las edades que estaban en el archivo con
#que se corrio kruskal



######Hasta aca vamos 1/feb/2019
#8. Evaluar diferencias entre grupos de niveles escolares utilizando prueba u de mann whitney con la funcion wilcox.test

getwd()
#setwd("E:/metas_5/graficas_normalidad/tablas_varianza/")
setwd("/media/navarreten/KINGSTON/metas_5/diferencias_grupos/tablas_diferencia_grupos/")
getwd()

datos<-data
grupos<-datos$Nivel

#source("E:/metas_5/f_levene.R")
source("/media/navarreten/KINGSTON/metas_5/f_wilcox.R")

prueba_wilcox(datos,grupos)

#9. Evaluar diferencias entre condiciones (por literal, metafora y absurdo) con prueba kruskall.wallis

ejercicio_b <-c(data$total_b_l,data$total_b_m,data$total_b_a)
condiciones<-c(rep("l",898),rep("m",898),rep("a",898))
condiciones<-as.factor(condiciones)

data13 <-data.frame(ejercicio_b,condiciones)
data13
View(data13)
kruskal.test(ejercicio_b,condiciones)

install.packages("dunn.test")
library(dunn.test)

dunn.test(data13$ejercicio_b,data13$condiciones,method="bonferroni", list=T)

#9. Evaluar diferencias entre tipologias (entre fisico-fisico, fisico-psicologico 
# y movimiento-tiempo) con prueba kruskall.wallis

ejercicio_c <-c(data$total_c_ff,data$total_c_fp,data$total_c_mt)
tipologias<-c(rep("ff",898),rep("fp",898),rep("mt",898))
tipologias<-as.factor(tipologias)

data14 <-data.frame(ejercicio_c,tipologias)
data14
View(data14)

kruskal.test(data14$ejercicio_c,data14$tipologias)
dunn.test(data14$ejercicio_c,data14$tipologias,method="bonferroni", list=T)

#10.Evaluar diferencias entre condiciones (literal, simil, metafora), con prueba kruskall.wallis
#La construccion de los vectores no se como hacerla, lo hare de forma manual. (Sacar las calificaciones por sujeto y por condicion)

#for (i in 75:110){
  #if{
  #variables[i-74]<-names(datos[i])
  #var<-as.numeric(as.vector(unlist(data16[,i])))
  #aux1<-bartlett.test(var~grupos) }
 #}

#library(tidyr)

#attach(data16)
#c<-gather(data16,d1_tipo,d1,key="categoria",value="puntaje") #gather es para pegar columnas o algo asi, pero no le entiendo bien 
#despues seguir explorando

library(dunn.test)

kruskal.test(data19$puntajes_d,data19$condiciones_d)
dunn.test(data19$puntajes_d,data19$condiciones_d,method="bonferroni", list=T)
write.csv()

#11. Calcular frecuencias para la presentacion

table(data$Grado)
barplot(data$Grado)
frec_esc <-table(data$Escuela)
sum(frec_esc[1:8])
write.csv(frec_esc, file ="frec_esc.csv", row.names = F)

frec_grado<-table(data$Grado)
sum(frec_grado[1:3])
sum(frec_grado[4:6])

frec_sexo<-table(data$Genero)


frec_sexo_grado<-table(data$Genero,data$Grado)
write.csv(frec_sexo_grado, file ="frec_sexo_grado.csv", row.names = F)

#12. Calcular medianas

a<-median(data9$gran_total)
data9$gran_total
summary(data9$gran_total)
summary(data10$gran_total)
summary(data$gran_total)
summary(data21$gran_total)
summary(data22$gran_total)
