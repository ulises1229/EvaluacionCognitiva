for (i in 4:8){
  grupos<-i
  prueba_levene(datos,grupos)}

#Esto se aproxima a lo que busco pero aun no se como hace que cada 
#cada archivo se vaya guardando, porque solo arroja el ultimo

for (i in 4:8){
  grupos<-unlist(datos[,i])
  prueba_levene(datos,grupos)}

#Este tambien funciona, pero es el mismo problema que el anterior

for (i in 4:8){
  grupos<-as.factor(datos[,i])
  prueba_levene(datos,grupos)}

#Este tambien funciona, pero es el mismo problema que el anterior

for (i in 4:8){
  grupos<-datos[,i]
  prueba_levene(datos,grupos)}

#Asi no funciona
for (i in 4:8){
  grupos<-datos[i]
  prueba_levene(datos,grupos)}

###

i <- NULL; aux <- NULL; r <- NULL

#promedio_variables <- data.frame(data[, 1:5])
#promedio_variables

for (i in 4:8){
  grupos<- datos[,i]
  aux <- prueba_levene(datos,grupos)
  r <- c(r,aux)
}


