
normalidad <-function(datos){
  
variables<-c()

jarque_pvalor<-c()
anderson_pvalor<-c()
kolmogorov_pvalor<-c()
pearson_pvalor<-c()
shapfran_pvalor<-c()
shapwilk_pvalor<-c()

jarque_estadistico<-c()
anderson_estadistico<-c()
kolmogorov_estadistico<-c()
pearson_estadistico<-c()
shapfran_estadistico<-c()
shapwilk_estadistico<-c()

jarque_distribucion<-c()
anderson_distribucion<-c()
kolmogorov_distribucion<-c()
pearson_distribucion<-c()
shapfran_distribucion<-c()
shapwilk_distribucion<-c()

for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(na.exclude(as.vector(unlist(datos[,i]))))
  
  aux1<-jarque.test(var)
  aux2<-ad.test(var)
  aux3<-lillie.test(var)
  aux4<-pearson.test(var)
  aux5<-sf.test(var)
  aux6<-shapiro.test(var)
  
  jarque_pvalor[i-9]<-aux1$p.value
  anderson_pvalor[i-9]<-aux2$p.value
  kolmogorov_pvalor[i-9]<-aux3$p.value
  pearson_pvalor[i-9]<-aux4$p.value
  shapfran_pvalor[i-9]<-aux5$p.value
  shapwilk_pvalor[i-9]<-aux6$p.value
  
  jarque_estadistico[i-9]<-aux1$statistic
  anderson_estadistico[i-9]<-aux2$statistic
  kolmogorov_estadistico[i-9]<-aux3$statistic
  pearson_estadistico[i-9]<-aux4$statistic
  shapfran_estadistico[i-9]<-aux5$statistic
  shapwilk_estadistico[i-9]<-aux6$statistic

  if (aux1$p.value<=0.05)
  {jarque_distribucion[i-9]<-"otra d."}
  
  else
  {jarque_distribucion[i-9]<-"d.normal"}
  
  if (aux2$p.value<=0.05)
  {anderson_distribucion[i-9]<-"otra d."}
  
  else
  {anderson_distribucion[i-9]<-"d.normal"}
  
  if (aux3$p.value<=0.05)
  {kolmogorov_distribucion[i-9]<-"otra d."}
  
  else
  {kolmogorov_distribucion[i-9]<-"d.normal"}
  
  if (aux4$p.value<=0.05)
  {pearson_distribucion[i-9]<-"otra d."}
  
  else
  {pearson_distribucion[i-9]<-"d.normal"}
  
  if (aux5$p.value<=0.05)
  {shapfran_distribucion[i-9]<-"otra d."}
  
  else
  {shapfran_distribucion[i-9]<-"d.normal"}
  
  if (aux6$p.value<=0.05)
  {shapwilk_distribucion[i-9]<-"otra d."}
  
  else
  {shapwilk_distribucion[i-9]<-"d.normal"}
  }  


normalidad_1<-data.frame(variables,jarque_estadistico,jarque_pvalor,jarque_distribucion,anderson_estadistico,anderson_pvalor,
                       anderson_distribucion,kolmogorov_estadistico,kolmogorov_pvalor,kolmogorov_distribucion,
                       pearson_estadistico,pearson_pvalor,pearson_distribucion,shapfran_estadistico,
                       shapfran_pvalor,shapfran_distribucion,shapwilk_estadistico,shapwilk_pvalor,shapwilk_distribucion)  
                       

normalidad_1

write.csv(normalidad_1, file ="normalidad.csv", row.names = F)

}






