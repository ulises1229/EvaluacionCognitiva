prueba_levene<-function(datos,grupos){

variables<-c()

levene_gradoslibertad<-c()
levene_estadistico<-c()#valores F
levene_pvalor<-c()#No estoy segura que esto sea pvalor, pero se interpreta como si lo fuera
levene_varianzas<-c()

for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(as.vector(unlist(datos[,i])))
  aux1<-leveneTest(var,grupos)
  levene_gradoslibertad[i-9]<-aux1$Df
  levene_estadistico[i-9]<-aux1$`F value`
  levene_pvalor[i-9]<-aux1$`Pr(>F)`
  
  
  if (aux1$`Pr(>F)`<=0.05)
  {levene_varianzas[i-9]<-"diferentes"}
  
  else
  {levene_varianzas[i-9]<-"iguales"}
  
}

varianzas_levene<-data.frame(variables,levene_gradoslibertad,levene_estadistico,
                            levene_pvalor,levene_varianzas)

#nombre_arch <- paste("varianzas_levene_",names(datos[7]),".csv", sep="")
write.csv(varianzas_levene, file ="varianzas_levene.csv", row.names = F) 

#write.csv(varianzas_levene,nombre_arch, row.names = F)

}