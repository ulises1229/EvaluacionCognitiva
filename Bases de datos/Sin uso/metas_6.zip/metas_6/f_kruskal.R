
prueba_kruskal<-function(datos,grupo1,grupo2,grupo3){
  
  variables<-c()

  edad_krusk_estadistico<-c()
  grado_krusk_estadistico<-c()
  escuela_krusk_estadistico<-c()
  
  edad_krusk_gradoslibertad<-c()
  grado_krusk_gradoslibertad<-c()
  escuela_krusk_gradoslibertad<-c()
  
  edad_krusk_pvalor<-c()
  grado_krusk_pvalor<-c()
  escuela_krusk_pvalor<-c()
  
  edad_krusk_difsignificativas<-c()
  grado_krusk_difsignificativas<-c()
  escuela_krusk_difsignificativas<-c()

for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(as.vector(unlist(datos[,i])))
  
  aux1<-kruskal.test(var~grupo1)
  aux2<-kruskal.test(var~grupo2)
  aux3<-kruskal.test(var~grupo3)
  
  edad_krusk_estadistico[i-9]<-aux1$statistic
  grado_krusk_estadistico[i-9]<-aux2$statistic
  escuela_krusk_estadistico[i-9]<-aux3$statistic
  
  edad_krusk_gradoslibertad[i-9]<-aux1$parameter
  grado_krusk_gradoslibertad[i-9]<-aux2$parameter
  escuela_krusk_gradoslibertad[i-9]<-aux3$parameter
  
  edad_krusk_pvalor[i-9]<-aux1$p.value
  grado_krusk_pvalor[i-9]<-aux2$p.value
  escuela_krusk_pvalor[i-9]<-aux3$p.value
  
  
  if (aux1$p.value<=0.05)
  {edad_krusk_difsignificativas[i-9]<-"Hay diferencias"}
  
  else
  {edad_krusk_difsignificativas[i-9]<-"No hay diferencias"}
  
  
  if (aux2$p.value<=0.05)
  {grado_krusk_difsignificativas[i-9]<-"Hay diferencias"}
  
  else
  {grado_krusk_difsignificativas[i-9]<-"No hay diferencias"}
  
  if (aux3$p.value<=0.05)
  {escuela_krusk_difsignificativas[i-9]<-"Hay diferencias"}
  
  else
  {escuela_krusk_difsignificativas[i-9]<-"No hay diferencias"}
  
}

diferencias_grupos<-data.frame(variables,edad_krusk_estadistico,edad_krusk_gradoslibertad,
                               edad_krusk_pvalor,edad_krusk_difsignificativas,variables,
                               grado_krusk_estadistico,grado_krusk_gradoslibertad,grado_krusk_pvalor,
                               grado_krusk_difsignificativas,variables,escuela_krusk_estadistico,
                               escuela_krusk_gradoslibertad,escuela_krusk_pvalor,
                               escuela_krusk_difsignificativas)


write.csv(diferencias_grupos, file ="kruskal_grupos.csv", row.names = F)

}