
#Esta funcion hay que mejorarla para poder obtener un archivo completo y rapido con todas las comparaciones. Asi como esta solo
#se pueden obtener los datos de la primera comparacion. Tomar en cuenta lo siguiente:

#Para extraer un elemento de un vector, hacemos asi:
#prueba$comparisons[2]

#Aqui empieza la funcion, mejorarla

prueba_dunn_1 <- function(datos,grupos)

variables<-c()

grado_dunn_comparaciones<-c()
grado_dunn_estadistico<-c()
grado_dunn_pvalor<-c()
grado_dunn_difsignificativas<-c()

for (i in 1:11){
  variables<-names(datos[i])
  var<-as.numeric(as.vector(unlist(datos[,i])))
  
  aux1<-dunn.test(var,grupos,method="bonferroni", list=T)
  
  grado_dunn_comparaciones[i]<-aux1$comparisons
  grado_dunn_estadistico[i]<-aux1$Z
  grado_dunn_pvalor[i]<-aux1$P.adjusted
  
  
  if (aux1$P.adjusted<=0.05)
  {grado_dunn_difsignificativas[i]<-"Significativa"}
  
  else
  {grado_dunn_difsignificativas[i]<-"No significativa"}


dunn_grupos<-cbind.data.frame(variables,grado_dunn_comparaciones,grado_dunn_estadistico,
                              grado_dunn_pvalor,grado_dunn_difsignificativas)

dunn_grupos

write.csv(dunn_grupos, file ="dunntest.csv", row.names = F)} 
