getwd()
#setwd("/media/navarreten/KINGSTON/metas_6")
#setwd("E:/metas_5")
getwd()

library (ggplot2)
library(scales)

datos<-data
datos
View(datos)

#Grafica Participantes por grado Escolar

ggplot(datos, aes(x=as.factor(Grado),fill=as.factor(Grado))) +
  geom_bar(stat="count", position="stack") + 
  scale_fill_hue(c = 40) +
  labs(title = "Numero de Participantes por Grado Escolar")+
  xlab("Grado Escolar")+
  ylab("Numero de participantes")+
  theme_linedraw()

ggsave("part_por_grado.jpeg")

#Otras opciones para color que tambien se pueden usar pero me gustaron mas las que puse

#fill=c("red","blue","yellow","orange","green","purple")
#geom_bar(stat="count", position="stack",fill=rgb(0.1,0.4,0.5,0.7)) 

#Grafica Participantes por Genero

ggplot(datos, aes(x=as.factor(Sexo),fill=as.factor(Sexo))) +
  geom_bar(width=0.4,stat="count", position="stack") + 
  scale_fill_brewer(palette = "Set1") +
  labs(title = "Numero de Participantes por Genero")+
  xlab("Genero")+
  ylab("Numero de participantes")+
  theme_linedraw()

ggsave("part_por_genero.jpeg")


#Grafica Participantes por Grado y Genero

ggplot(datos, aes(x=as.factor(Grado), fill=Genero) ) +
  labs(title = "Participantes por Grado y Genero")+
  xlab("Grado")+
  ylab("Numero de participantes") +
  theme(axis.title.x = element_text(face="bold",size=10),plot.title = element_text(size=rel(1.5)))+
  geom_bar(position="dodge")+
  scale_fill_brewer(palette = "Set1")+
  theme_linedraw()

ggsave("part_por_grado_y_genero.jpeg")

#Boxplot diferencia entre generos

ggplot(datos, aes(x=as.factor(Genero),y=(gran_total), fill=as.factor(Genero))) + 
  geom_boxplot(alpha=0.2, notch = T) + 
  labs(title = "Diferencias entre Genero")+
  ylab("Numero total de aciertos")+
  xlab("Genero")+
  scale_fill_brewer(palette = "Set1") +
  theme_minimal()

ggsave("E:/metas_5/diferencias_sexo/graficas_diferencia_sexo/diferencias_genero.jpeg")

#Boxplot diferencia entre grupos


ggplot(datos, aes(x=as.factor(Grado),y=(gran_total), fill=as.factor(Grado))) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Grados Escolares")+
  ylab("Numero total de aciertos")+
  xlab("Grado Escolar")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()

ggsave("E:/metas_5/diferencias_grupos/graficas_diferencias_grupos/grado/diferencias_grado_grantotal.jpeg")
  
#Boxplot diferencia entre edades  
  
ggplot(datos, aes(x=as.factor(Edad),y=(gran_total), fill=as.factor(Edad))) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Grupos de Edad")+
  ylab("Numero total de aciertos")+
  xlab("Edad")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()

ggsave("E:/metas_5/diferencias_grupos/graficas_diferencias_grupos/edad/diferencias_edad_grantotal.jpeg")


#Boxplot diferencia entre escuelas
#Actualizado

levels(datos$Escuela)
levels(orden_escuelas)

orden_escuelas = factor(datos$Escuela, levels=c("Americas Unidas","Colegio Nuevo Milenio","Republica Francesa",
                               "Calli Montessori","Secundaria Tecnica 14","Saint Agustine School",
                              "ISQ","Carol Baur"))


orden_escuelas = factor(datos$Escuela, levels=c("Americas Unidas","Calli Montessori","Colegio Nuevo Milenio","Republica Francesa",
                                                "Carol Baur","ISQ","Saint Agustine School","Secundaria Tecnica 14"))




install.packages("ggpubr")

library(ggpubr)
library (ggplot2)
library(scales)
library(dunn.test)

datos<-data


ggplot(datos, aes(x=orden_escuelas,y=gran_total, fill=orden_escuelas)) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Escuelas")+
  ylim(0,220)+
  ylab("Numero total de aciertos")+
  xlab("Escuelas")+
  scale_fill_brewer(palette="Set1") +
  theme_minimal()+
  stat_compare_means(method = "dunn.test", label.y =3.5) +
  stat_compare_means(label = "p.signif", ref.group = ".all.", size = 5, hide.ns = TRUE,
                     comparisons = list(c("Americas Unidas","Republica Francesa"),c("Americas Unidas","Carol Baur"), 
                                        c("Americas Unidas","ISQ"),c("Americas Unidas","Saint Agustine School"),
                                        c("Americas Unidas","Secundaria Tecnica 14"),
                                        c("Calli Montessori","Carol Baur"),c("Calli Montessori","Saint Agustine School"),
                                        c("Colegio Nuevo Milenio","Carol Baur"),c("Colegio Nuevo Milenio","ISQ"),
                                        c("Colegio Nuevo Milenio","Saint Agustine School"),
                                        c("Republica Francesa","Carol Baur"),c("Republica Francesa","ISQ"),
                                        c("Republica Francesa","Saint Agustine School"),
                                        c("Secundaria Tecnica 14","Carol Baur"),c("Secundaria Tecnica 14","ISQ"), 
                                        c("Saint Agustine School","Secundaria Tecnica 14")))

ggsave("E:/metas_6/diferencias/grupos/graficas_dif_grupos/diferencias_escuela_grantotal.jpeg")


#Boxplot diferencia entre niveles (primaria-secundaria)

ggplot(datos, aes(x=as.factor(Nivel),y=(gran_total), fill=as.factor(Nivel))) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre Nivel Escolar")+
  ylab("Numero total de aciertos")+
  xlab("Nivel Escolar")+
  scale_fill_brewer(palette = "Set1") +
  theme_minimal()+
  stat_compare_means(method = "wilcox.test", label = "p.signif",
                     ref.group = ".all.", size = 5, hide.ns = TRUE,
                     comparisons = list(c(1,2)))

ggsave("E:/metas_6/diferencias/nivel/diferencias_nivel_grantotal.jpeg")

#Boxplot diferencia entre condiciones ejercicio b

levels(data13$condiciones)
levels(orden_escuelas)

condiciones_lma = factor(data13$condiciones, levels=c("l","m","a"))
condiciones_lam = factor(data13$condiciones, levels=c("l","a","m"))
                         
ggplot(data13, aes(x=condiciones_lam,y=ejercicio_b, fill=as.factor(condiciones_lam))) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre condiciones. Ejercicio 2")+
  ylab("Puntajes")+
  xlab("Condiciones")+
  scale_fill_brewer(palette = "Set1") +
  theme_minimal()

#ggsave("/media/pinker/KINGSTON/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_condiciones_ejercicio_b.jpeg")
#ggsave("E:/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_condiciones_ejercicio_b.jpeg")
ggsave("/media/navarreten/KINGSTON/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_condiciones_ejercicio_b.jpeg")

#Boxplot diferencia entre tipologias ejercicio c

ggplot(data14, aes(x=tipologias,y=ejercicio_c, fill=as.factor(tipologias))) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre tipologias. Ejercicio 3")+
  ylab("Puntajes")+
  xlab("Tipologias")+
  scale_fill_brewer(palette = "Set1") +
  theme_minimal()

#ggsave("/media/pinker/KINGSTON/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_tipologias_ejercicio_c.jpeg")
#ggsave("/media/navarreten/KINGSTON/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_tipologias_ejercicio_c.jpeg")

ggsave("E:/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_tipologias_ejercicio_c.jpeg")

#Boxplot diferencia entre tipologias ejercicio d

condiciones_lsa = factor(data19$condiciones_d, levels=c("l","s","m"))

ggplot(data19, aes(x=condiciones_lsa,y=puntajes_d, fill=as.factor(condiciones_lsa))) + 
  geom_boxplot(alpha=0.5, notch = T) + 
  labs(title = "Diferencias entre condiciones. Ejercicio 4")+
  ylab("Puntajes")+
  xlab("Condiciones")+
  scale_fill_brewer(palette = "Set1") +
  theme_minimal()

ggsave("/media/navarreten/KINGSTON/metas_5/diferencias_condiciones/graficas_diferencias_condiciones/diferencias_condiciones_ejercicio_d.jpeg")

#Grafica Participantes por grado Escolar

for (i in 1:9){
  variables[i]<-variable.names(data20[i])
  nombre <- paste(variables[,i], ".csv", sep="")
  
ggplot(data20, aes(x=as.factor(i),fill=as.factor(i))) +
  geom_bar(stat="count", position="stack") + 
  scale_fill_hue(c = 40) +
  labs(title = variables[,i]) +
  xlab("rutas")+
  ylab("Numero de casos")+
  theme_linedraw()

ggsave(nombre)

}


for (i in 1:9){

  ggplot(data20, aes(x=as.factor(i),fill=as.factor(i))) +
    geom_bar(stat="count", position="stack") + 
    scale_fill_hue(c = 40) + 
    xlab("rutas")+
    ylab("Numero de casos")+
    theme_linedraw()
  
}


ggplot(data20, aes(x=as.factor(data20$b3_ruta),fill=as.factor(data20$b3_ruta))) +
  geom_bar(stat="count", position="stack") + 
  scale_fill_hue(c = 40) +
  labs(title = "absurdo") +
  xlab("rutas")+
  ylab("Numero de casos")+
  theme_linedraw()+
  coord_flip()

ggsave("absurdo_ff.jpeg")





