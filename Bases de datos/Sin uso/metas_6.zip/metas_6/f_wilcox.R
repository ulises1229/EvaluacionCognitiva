
prueba_wilcox<-function(datos,grupos){

variables<-c()

wilcox_estadistico<-c()
wilcox_pvalor<-c()
wilcox_conclusion<-c()

for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(as.vector(unlist(datos[,i])))
  aux1<-wilcox.test(var~grupos)
  wilcox_estadistico[i-9]<-aux1$statistic
  wilcox_pvalor[i-9]<-aux1$p.value
  
  if (aux1$p.value<=0.05)
  {wilcox_conclusion[i-9]<-"diferentes"}
  
  else
  {wilcox_conclusion[i-9]<-"iguales"}
  
}

diferencias<-data.frame(variables,wilcox_estadistico,wilcox_pvalor,
                             wilcox_conclusion)

write.csv(diferencias, file ="diferencias.csv", row.names = F)

}
