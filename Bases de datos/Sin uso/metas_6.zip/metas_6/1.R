sample(1:2,21,replace=T)
citation()
kruskal.test(data$gran_total ~ data$Sexo)
wilcox.test(data$gran_total ~ data$Sexo)
median(data21$gran_total)
median(data22$gran_total)

#Esto no se porque no funcion�, entonces se intent� lo siguiente
#data23<-read.csv("data23.csv")

#siguiente:

library(readr)

data23 <- read_csv("data23.csv")
View(data23)

friedman.test(data23$totales_2, data23$condicion, data23$np_cont)
pairwise.wilcox.test(data23$totales_2, data23$condicion, paired = TRUE, p.adjust.method = "holm")
