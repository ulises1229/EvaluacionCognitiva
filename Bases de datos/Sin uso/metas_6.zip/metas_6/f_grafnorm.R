grafnorm <-function(datos){

for (i in 10:42){
  variables[i-9]<-names(datos[i])
  var<-as.numeric(na.exclude(as.vector(unlist(datos[,i]))))
  
  pdf(paste0("qqplot_",names(datos[i]),".pdf"), paper = "USr")
  qqnorm(var,main =names(datos[i]) )
  qqline(var)
  dev.off()
  
  pdf(paste0("histograma_",names(datos[i]),".pdf"), paper = "USr")
  hist(var,main =names(datos[i]))
  dev.off()
  
  pdf(paste0("densidad_",names(datos[i]),".pdf"), paper = "USr")
  plot(density(var),main =names(datos[i]))
  dev.off()
  
}
}
