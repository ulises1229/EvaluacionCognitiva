getwd()
setwd("E:/metas_6")
#setwd("/media/navarreten/KINGSTON1/metas_6")
setwd("/media/navarreten/KINGSTON/metas_6")
#setwd("/media/pinker/KINGSTON/metas_6")
getwd()

rm(data)
#data<-read.csv("E:/metas_6/3_hm_ps_var_6.csv")
data<-read.csv("3_hm_ps_var_6.csv")
View(data)


data1<-subset(data,Edad==9)
#data1
#View(data1)

data2<-subset(data,Edad==10)
#data2
#View(data2)

data3<-subset(data,Edad==11)
#data3
#View(data3)

data4<-subset(data,Edad==12)
#data4
#View(data4)

data5<-subset(data,Edad==13)
#data5
#View(data5)

data6<-subset(data,Edad==14)
#data6
#View(data6)

data7<-subset(data,Edad==15)
#data7
#View(data7)

data8<-subset(data,Edad==16)
#data8
#View(data8)

data9<-subset(data,Sexo=="F")
#data9
View(data9)

data10<-subset(data,Sexo=="M")
#data10
View(data10)

#data11= todos los totales: parciales y generales
data11<-data[,grepl(pattern = "total", x = names(data))]
#data11
View(data11)


#data12= Los totales generales de cada ejercicio (totales de cada prueba(a,b,c y d) 
#y el total general (gran_total))

data12<-data[,grepl(pattern = "total_a|total_b$|total_c$|total_d|gran_total",x = names(data))]
#data12
View(data12)

#data13=Un data frame de 2 columnas donde la primer variable es el total de cada condicion del ejercicio b
#(literal, metafora y absurdo) y la segunda es un vector con las condiciones que corresponden a cada
#puntaje de la primer columna

ejercicio_b <-c(data$total_b_l,data$total_b_m,data$total_b_a)
condiciones<-c(rep("l",898),rep("m",898),rep("a",898))
condiciones<-as.factor(condiciones)

data13 <-data.frame(ejercicio_b,condiciones)
#data13
View(data13)

#data14= Un data frame de 2 columnas donde la primer variable es el total de cada tipologia del ejercicio c 
#obre metaforas (fisico-fisico, fisico-psicologico y movimiento-tiempo)) y la segunda es un vector con las 
#condiciones (tipologias) que corresponden a cada puntaje de la primer columna

ejercicio_c <-c(data$total_c_ff,data$total_c_fp,data$total_c_mt)
tipologias<-c(rep("ff",898),rep("fp",898),rep("mt",898))
tipologias<-as.factor(tipologias)

data14 <-data.frame(ejercicio_c,tipologias)
#data14
View(data14)

#data15=Tabla 2 donde se incluyen caracteristicas cualitativas de las variables (categorias)

data15 <-read.csv("2_hm_ps_con.csv")
#data15
View(data15)

#Ahora vamos a hacer subconjuntos de data 15 (Tabla 2) (2_hm_ps_con.csv)

#data16=subconjunto de los ejercicios version 1 (sea 1a o 1b)

#data16 <-subset(data15,d_tipo_ejs==1)
#data16
#View(data16)

#data17=subconjunto de los ejercicios version 2 (sea 2a o 2b)

#data17 <-subset(data15,d_tipo_ejs==2)
#data16
#View(data17)

#data18=subconjunto de los ejercicios version 3 (sea 2a o 2b)

#data18 <-subset(data15,d_tipo_ejs==3)
#data16
#View(data18)

#data19= Un data frame de 2 columnas donde la primer variable es el total de cada condicion del ejercicio d 
#(literal, simil y metafora)) y la segunda es un vector con las 
#condiciones (tipologias) que corresponden a cada puntaje de la primer columna

#se tuvo que hacer de forma manual, 

#puntajes_d <-c(data15$total_d_p1,data15$total_d_p2,data15$total_d_p3)

#a<-as.character(data15$cond_d_p1)
#b<-as.character(data15$cond_d_p2)
#c<-as.character(data15$cond_d_p3)
#condiciones_d<-c(a,b,c)
#condiciones_d<-as.factor(condiciones_d)
         
#data19 <-data.frame(puntajes_d,condiciones_d)
#data14
#View(data19)
#write.csv(data19, file ="data19", row.names = F)

#como se tuvo que eliminar posteriormente la fila 217(porque no tenia nada), tuvo que 
#hacerse esto

#data19<-read.csv("data19.csv")
#View(data19)

#Solo rutas de resolucion de reactivos de ejercicio 2 (MMA, LMA y asi)hombres y mujeres
#primaria y secundaria

rm(data20)
data20 <-read.csv("rutas_b_ps_2.csv")

#data21=Primaria

data21<-subset(data,Nivel=="1")
#data21
View(data21)

#data22=Secundaria

data22<-subset(data,Nivel=="2")
#data10
View(data22)
